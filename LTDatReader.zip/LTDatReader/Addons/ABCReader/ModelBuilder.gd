extends Node

# ABC --> Godot Koordinatensystem-Korrektur
var mirror_abc_for_godot = true  # Für Links-Rechts Spiegelung

# Just the skeleton I can access anywhere, mostly for debug purposes
var cheat_skeleton := Skeleton.new()

var model = null

func build(source_file, options):
	var file = File.new()
	if file.open(source_file, File.READ) != OK:
		print("Failed to open " + source_file)
		return FAILED
		
	print("Opened " + source_file)
	
	var path = self.get_script().get_path().get_base_dir() + "/Models"
	var abc_file = load(path + "/ABC.gd")
	var abc6_file = load(path + "/ABC6.gd")
	
	# Our helper script
	var abc_helper_script = load(self.get_script().get_path().get_base_dir() + "/ABCHelper.gd")
	
	var model = abc_file.ABC.new()
	
	var response = model.read(file)
	if response.code == model.IMPORT_RETURN.ERROR:
		print("Checking ABC version 6 reader!")
		# Try ABC 6
		model = abc6_file.ABC.new()
		response = model.read(file)
		
		#...nope, we're ded.
		if response.code == model.IMPORT_RETURN.ERROR:
			file.close()
			print("IMPORT ERROR: " + str(response.message))
			return FAILED
	
	self.model = model	
		
	# Actually close the darn thing
	file.close()
		
	# Setup our new scene
	var scene = PackedScene.new()
	
	# Create our nodes
	var root = Spatial.new()
	
	# Setup the nodes
	root.name = "Root"
	
	root.set_script(abc_helper_script)
	
	var skeleton = Skeleton.new()
	skeleton.name = "Skeleton"
	skeleton = build_skeleton(model, skeleton)
	root.add_child(skeleton)
	skeleton.owner = root
	self.cheat_skeleton = skeleton
	
	print("=== SKELETON DEBUG ===")
	print("Skeleton hat ", skeleton.get_bone_count(), " Bones")
	for i in range(skeleton.get_bone_count()):
		var bone_name = skeleton.get_bone_name(i)
		var parent_idx = skeleton.get_bone_parent(i)
		var rest_transform = skeleton.get_bone_rest(i)
		print("Bone ", i, ": ", bone_name, " | Parent: ", parent_idx)
		print("  Rest Transform: ", rest_transform)
	
	var meshes = fill_array_mesh(model, skeleton)
	
	# DTX Texture Loading Setup
	#var texture_path = get_dtx_path(source_file)
	var texture_builder = load("res://addons/DTXReader/TextureBuilder.gd").new()
	
	# # Loop through our pieces, and add them to mesh instances
	# for i in range(len(meshes)):
		# var mesh = meshes[i]
		# var piece = model.pieces[i]
		# var mesh_instance = MeshInstance.new()
		# mesh_instance.name = piece.name
		# mesh_instance.mesh = mesh
		
		# # Create material with DTX texture
		# var material = SpatialMaterial.new()
		
		# if File.new().file_exists(texture_path):
			# var texture = texture_builder.build(texture_path, {})
			# if texture != null:
				# material.albedo_texture = texture
				# print("Texture geladen: ", texture_path)
			# else:
				# print("DTX-Fehler: ", texture_path)
		# else:
			# print("DTX nicht gefunden: ", texture_path)
		
		# mesh_instance.material_override = material
		# skeleton.add_child(mesh_instance)
		# mesh_instance.owner = root
	# # End For
	
	# Loop through our pieces, and add them to mesh instances
	for i in range(len(meshes)):
		var mesh = meshes[i]
		var piece = model.pieces[i]
		var mesh_instance = MeshInstance.new()
		mesh_instance.name = piece.name
		mesh_instance.mesh = mesh
		
		# ABC --> Godot Koordinatensystem-Korrektur (DIESE ZEILE HINZUFÜGEN)
		if mirror_abc_for_godot:
			mesh_instance.scale = Vector3(-1.0, 1.0, 1.0)
		
		# Create material with DTX texture
		var material = SpatialMaterial.new()
		
		# HIER: Texture-Path für jedes Piece einzeln berechnen
		var texture_path = get_dtx_path(source_file, piece.material_index)
		print("Piece: ", piece.name, " Material_Index: ", piece.material_index, " -> Texture: ", texture_path)
		
		if File.new().file_exists(texture_path):
			var texture = texture_builder.build(texture_path, {})
			if texture != null:
				material.albedo_texture = texture
				print("Texture geladen: ", texture_path)
			else:
				print("DTX-Fehler: ", texture_path)
		else:
			print("DTX nicht gefunden: ", texture_path)
		
		mesh_instance.material_override = material
		skeleton.add_child(mesh_instance)
		mesh_instance.owner = root
	# End For
	
	# Animation time!
	var anim_player = AnimationPlayer.new()
	anim_player.name = "AnimPlayer"
	root.add_child(anim_player)
	anim_player.owner = root
	anim_player = process_animations(model, anim_player)
	
	#autoset camera to scene
	# called from ModelRendererController after add_child
	
	# Model aufrecht stellen:
	#root.rotation_degrees = Vector3(0, 0, -90)
	
	# Pack our scene!
	scene.pack(root)
	
	# Clean up!
	#root.queue_free()
	
	return scene

func get_dtx_path(abc_path: String, material_index: int) -> String:
	var base_dir = abc_path.get_base_dir()
	var base_name = abc_path.get_file().get_basename()
	var skin_dir = base_dir.replace("models_pv", "skins_pv").replace("models", "skins")
	
	# Prüfe ob es ein Gun-Model ist
	var is_gun = abc_path.to_lower().find("guns") != -1
	
	if material_index == 0:
		# Index 0 = Haupt-Model-Texture (für alle)
		return skin_dir + "/" + base_name + ".dtx"
	elif material_index == 1:
		if is_gun:
			# Guns: Index 1 = Action Hands
			return skin_dir + "/actionhands_pv.dtx"
		else:
			# Characters: Index 1 = Head Texture
			return skin_dir + "/" + base_name + "_head.dtx"
	else:
		# Fallback für andere Indices
		return skin_dir + "/" + base_name + "_" + str(material_index) + ".dtx"

# func get_dtx_path(abc_path: String) -> String:
	# var base_dir = abc_path.get_base_dir()
	# var file_name = abc_path.get_file().replace(".abc", ".dtx")
	
	# # models_pv --> skins_pv
	# if base_dir.ends_with("models_pv"):
		# return base_dir.replace("models_pv", "skins_pv") + "/" + file_name
	
	# # models --> skins  
	# elif base_dir.ends_with("models"):
		# return base_dir.replace("models", "skins") + "/" + file_name
	
	# # Fallback: gleicher Ordner
	# return base_dir + "/" + file_name

# func build(source_file, options):
	# var file = File.new()
	# if file.open(source_file, File.READ) != OK:
		# print("Failed to open " + source_file)
		# return FAILED
		
	# print("Opened " + source_file)
	
	# var path = self.get_script().get_path().get_base_dir() + "/Models"
	# var abc_file = load(path + "/ABC.gd")
	# var abc6_file = load(path + "/ABC6.gd")
	
	# # Our helper script
	# var abc_helper_script = load(self.get_script().get_path().get_base_dir() + "/ABCHelper.gd")
	
	# var model = abc_file.ABC.new()
	
	# var response = model.read(file)
	# if response.code == model.IMPORT_RETURN.ERROR:
		# print("Checking ABC version 6 reader!")
		# # Try ABC 6
		# model = abc6_file.ABC.new()
		# response = model.read(file)
		
		# #...nope, we're ded.
		# if response.code == model.IMPORT_RETURN.ERROR:
			# file.close()
			# print("IMPORT ERROR: " + str(response.message))
			# return FAILED
	
	# self.model = model	
		
	# # Actually close the darn thing
	# file.close()
		
	# # Setup our new scene
	# var scene = PackedScene.new()
	
	# # Create our nodes
	# var root = Spatial.new()
	
	# # Setup the nodes
	# root.name = "Root"
	
	# root.set_script(abc_helper_script)
	
	# var skeleton = Skeleton.new()
	# skeleton.name = "Skeleton"
	# skeleton = build_skeleton(model, skeleton)
	# root.add_child(skeleton)
	# skeleton.owner = root
	# self.cheat_skeleton = skeleton
	
	# print("=== SKELETON DEBUG ===")
	# print("Skeleton hat ", skeleton.get_bone_count(), " Bones")
	# for i in range(skeleton.get_bone_count()):
		# var bone_name = skeleton.get_bone_name(i)
		# var parent_idx = skeleton.get_bone_parent(i)
		# var rest_transform = skeleton.get_bone_rest(i)
		# print("Bone ", i, ": ", bone_name, " | Parent: ", parent_idx)
		# print("  Rest Transform: ", rest_transform)
	
	# var meshes = fill_array_mesh(model, skeleton)
	# #var meshes = fill_array_mesh(model)

	# # Loop through our pieces, and add them to mesh instances
	# for i in range(len(meshes)):
	# #for mesh in meshes:
		# var mesh = meshes[i]
		# var piece = model.pieces[i]
		# var mesh_instance = MeshInstance.new()
		# mesh_instance.name = piece.name
		# mesh_instance.mesh = mesh
		# skeleton.add_child(mesh_instance)
		# mesh_instance.owner = root
	# # End For
	
	# # Animation time!
	# var anim_player = AnimationPlayer.new()
	# anim_player.name = "AnimPlayer"
	# root.add_child(anim_player)
	# anim_player.owner = root
	# anim_player = process_animations(model, anim_player)
	
	# # Pack our scene!
	# scene.pack(root)
	
	# # Clean up!
	# root.queue_free()
	
	# return scene

func fill_array_mesh(model, skeleton):
	var meshes = []
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	
	print("=== SKELETON INFO ===")
	print("Skeleton hat ", skeleton.get_bone_count(), " Bones")

	for piece in model.pieces:
		var verts = PoolVector3Array()
		var uvs = PoolVector2Array()
		var normals = PoolVector3Array()
		var indices = PoolIntArray()
		
		# Holds vertex_bone_data
		# Basically the weights per a vertex
		var piece_bone_data = []
		
		# Count
		var vert_weight_count = PoolIntArray()
		
		for lod in piece.lods:
			for vertex in lod.vertices:
				verts.append(vertex.location)
				normals.append(vertex.normal)
				vert_weight_count.append(vertex.weight_count)
				var vertex_bone_data = []
				for weight in vertex.weights:
					vertex_bone_data.append([weight.node_index, weight.bias])
				# End For
				piece_bone_data.append(vertex_bone_data)
			# End For
			for face in lod.faces:
				for vertex in face.vertices:
					var texcoord = vertex.texcoord
					var vertex_index = vertex.vertex_index
					
					uvs.append( Vector2( texcoord.x, texcoord.y ) )
					indices.append(vertex_index)
				# End For
			# End For
			# Only want the first LOD
			break
		# End For
		
		# If we need to flip the indices, then do so
		# This applies to pretty much every model except for Shogo, and Blood 2...
		if !model.front_to_back_indices:
			indices.invert()
			uvs.invert()
			
		var i = 0
		for index in indices:
			st.add_uv(uvs[i])
			st.add_normal(normals[index])
			
			var this_vert_bones = PoolIntArray()
			var this_vert_weights = PoolRealArray()
			
			# Index 0: Node Index
			# Index 1: Bias
			for bone_data in piece_bone_data[index]:
				this_vert_bones.append(bone_data[0])
				this_vert_weights.append(bone_data[1])
			# End For
			
			# For some reason these MUST be 4 values each!
			var remainder = 4 - vert_weight_count[index]
			for filler in range(remainder):
				this_vert_bones.append(-1)
				this_vert_weights.append(0.0)
			# End For
				
			#st.add_bones(this_vert_bones)
			#st.add_weights(this_vert_weights)
			
			st.add_vertex(verts[index])
			i += 1
		
		meshes.append(st.commit())
		
		# Clear out the previous piece
		st.clear()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)


	return meshes
# End Func


		
func build_skeleton(model, skeleton : Skeleton):
	# Pass 1: add all bones first
	for i in range(model.node_count):
		var lt_node = model.nodes[i]
		skeleton.add_bone(lt_node.name)
	# Pass 2: set parents and rest transforms
	for i in range(model.node_count):
		var lt_node = model.nodes[i]
		var bind_matrix = lt_node.bind_matrix
		if lt_node.parent != null:
			skeleton.set_bone_parent(i, lt_node.parent.index)
			bind_matrix = lt_node.parent.bind_matrix.inverse() * bind_matrix
		
		skeleton.set_bone_rest(i, bind_matrix)
	# End For
		
	return skeleton
# End Func


func process_animations(model, anim_player : AnimationPlayer):
	
	for lt_anim in model.animations:
		var anim = Animation.new()
		# Pre-make our track ids
		for ni in range(model.node_count):
			var key = "Skeleton:" + model.nodes[ni].name
			var track_id = anim.add_track(Animation.TYPE_TRANSFORM)
			anim.track_set_path(track_id, key)
		# End For
		
		var last_scaled_key = 0
		for kfi in range(lt_anim.keyframe_count):
			var lt_keyframe = lt_anim.keyframes[kfi]
			var scaled_key = lt_keyframe.time
			if scaled_key != 0:
				scaled_key /= 1000.0
			# End If
			self.recursively_apply_transform(model, 0, kfi, lt_anim, anim, scaled_key, Transform.IDENTITY)
			last_scaled_key = scaled_key

			# Check for command string...
			if lt_keyframe.command_string != "":
				var key = "." # Root
				var track_id = anim.add_track(Animation.TYPE_METHOD)
				anim.track_set_path(track_id, key)
				anim.track_insert_key(track_id, scaled_key, {"method": "run_command_string", "args": [ lt_keyframe.command_string ]})
			# End If	

		# End For
		
		anim.length = last_scaled_key
		anim_player.add_animation(lt_anim.name, anim)
	# End For
	
	return anim_player
# End Func

func auto_frame_camera(model_root, camera = null):
	# Berechne die Bounding Box des gesamten Models
	var aabb = AABB()
	var first_mesh = true
	
	for child in model_root.get_children():
		if child is Skeleton:
			for mesh_child in child.get_children():
				if mesh_child is MeshInstance and mesh_child.mesh != null:
					var mesh_aabb = mesh_child.mesh.get_aabb()
					mesh_aabb = mesh_child.transform.xform(mesh_aabb)
					
					if first_mesh:
						aabb = mesh_aabb
						first_mesh = false
					else:
						aabb = aabb.merge(mesh_aabb)
	
	if first_mesh:  # Kein Mesh gefunden
		return
	
	# Berechne Kamera-Position
	var model_center = aabb.position + aabb.size * 0.5
	var model_size = aabb.size.length()
	var camera_distance = model_size * 1.5  # 1.5x Abstand für gute Sicht
	
	# Kamera positionieren (45° Winkel von vorne-rechts-oben)
	var camera_offset = Vector3(camera_distance * 0.7, camera_distance * 0.5, camera_distance * 0.7)
	var camera_position = model_center + camera_offset
	
	print("Model AABB: ", aabb)
	print("Kamera Position: ", camera_position, " -> Ziel: ", model_center)
	
	# Falls Sie Zugriff auf die Kamera haben:
	# camera.global_transform.origin = camera_position
	# camera.look_at(model_center, Vector3.UP)

# This is quite a function!
# Call this within a keyframe loop
func recursively_apply_transform(model, node_index, keyframe_index, lt_anim, godot_anim : Animation, scaled_key, parent_matrix):
	var node = model.nodes[node_index]
	
	var transform = lt_anim.node_keyframes[node_index][keyframe_index]
	var matrix = self.lt_transform_to_godot_transform(transform.location, transform.rotation)
	var matrix_copy = matrix
	
	# This is the thing that's broken for version 9-13 animations!
	if model.version > 6:
		matrix = parent_matrix * matrix 
		matrix_copy = matrix
		#matrix = node.inverse_bind_matrix * matrix
		matrix = cheat_skeleton.get_bone_rest(node_index).inverse() * matrix
		#matrix *= node.bind_matrix
		#matrix = parent_matrix * matrix 

	var translation = matrix.origin 
	var rotation  = matrix.basis.get_rotation_quat()
	
	# Needed for v6!
	if model.flip_anim:
		rotation = rotation.inverse()
	
	# Node index SHOULD equal track id!
	godot_anim.transform_track_insert_key(node_index, scaled_key, translation, rotation, Vector3(1.0, 1.0, 1.0))
	
	# Now recursively crawl through the child nodes
	for child_index in node.child_count:
		node_index += 1
		node_index = recursively_apply_transform(model, node_index, keyframe_index, lt_anim, godot_anim, scaled_key, matrix_copy)
	# End For
	
	return node_index
# End Func

func lt_transform_to_godot_transform(loc, rot):
	var transform = Transform()
	var basis = Basis(rot)
	transform.basis = basis
	transform.origin = loc
	return transform
	
